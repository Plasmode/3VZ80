/* Quartus II Version 8.1 Build 163 10/28/2008 SJ Full Version */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM240T100) Path("C:/quartwrk81/HomeProjects/EPM240/3VZ80/") File("top.pof") MfrSpec(OpMask(3) SEC_Device(EPM240T100) Child_OpMask(2 3 3));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
