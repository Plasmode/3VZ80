;output to serial port continuously
SerData	equ 81h
SerStat	equ 80h
	org 0
	ld a,0
scream:
	ld a,b
	out (SerData),a
	inc b
chkTxE:
	in a,(SerStat)
	and 2		;check TxEmpty
	jr z,chkTxE
	jr scream

	end

