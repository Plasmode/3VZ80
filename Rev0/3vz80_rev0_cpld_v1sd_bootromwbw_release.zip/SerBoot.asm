;output to serial port continuously
SerData	equ 81h
SerStat	equ 80h
	org 0
	ld a,'>'
	out (SerData),a
	ld hl,0b000h		;serial bootstrap in memory
chkRxRdy:
	in a,(SerStat)
	and 1
	jr z,chkRxRdy
	in a,(SerData)
	ld (hl),a
	inc l
	jr nz,chkRxRdy
	jp 0b000h


	end

