;output to serial port continuously
SerData	equ 81h
SerStat	equ 80h
	org 0
	ld a,0
scream:
	out (SerData),a
	inc a
spin:
	dec b
	jr nz,spin
	jr scream
	end

